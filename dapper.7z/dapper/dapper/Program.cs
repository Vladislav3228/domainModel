﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace dapper
{
    class Program
    {
        static void Main(string[] args)
        {
            string connString = "Server=localhost;Port=3306;Database=mybase;Uid=root;password='';";
            MySqlConnection conn = new MySqlConnection(connString);
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = "SELECT item, state FROM cells WHERE id = 1";
            try
            {
                conn.Open();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            MySqlDataReader reader = comm.ExecuteReader();
            while (reader.Read())
            {
                Console.WriteLine("ячейка " + reader["state"].ToString());
                Console.WriteLine("в ней " + reader["item"].ToString());
            }
            Console.ReadLine();
        }
    }
}
